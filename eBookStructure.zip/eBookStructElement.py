﻿# coding=UTF-8
"""
 Copyright (C) 2012 Jürgen Baumeister

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
eBookStructElement.py
#=====================================================================================================
A class to model the information structure needed for a epub type eBook
"""

#=====================================================================================================
# Import section
#=====================================================================================================


#=====================================================================================================
# Class eBookStructElement
#=====================================================================================================
class eBookStructElement:

    #=================================================================================================
    # initializing the application class
    #=================================================================================================
    def __init__(self, tag, parent=None):
        """
        Create a new structure element for an eBook structure
        This method only takes a tag name (string). If given the parent is
        also set
        """
        self.parent = parent           # The eBookStructElement, this object is a child of
        self.tag = tag                     # A string naming the element (correspondes with the tag name in xml
        self.attributes = []             # Key value pairs, corresponding with the attributes in xml
        self.content = ''                # The content (string) of the element
        self.children = []                # A list of eBookStructElements, that are children of this object
                                                   # this way it is possible to build up complex trees

    #=================================================================================================
    # managing the tree
    #=================================================================================================
    def addChild(self, child, pos=None):
        """
        Add a child element to the actual element.
        If pos is None, the child is appended to the list of children. Otherwise
        the child is inserted at the given position. If position is not existing,
        the new child is also appended
        """

        if isinstance(child, str):
            newchild = eBookStructElement(child)
        elif isinstance(child, eBookStructElement):
            newchild = child
        else:
            raise TypeError

        newchild.parent = self

        if (pos == None or pos > len(self.children)):
            self.children.append(newchild)
        else:
            self.children.insert(pos, newchild)

    def __getitem__(self, path):
        """
        Method to retrieve an element, defined by a path string.
        This is a method, that enables the object[path] syntax of python
        The method uses the __findtree__ method to recursively search for the
        queried element
        """
        if not isinstance(path, str):  # path must be a string in the format 'element/element/element'
            raise TypeError
        
        # split the path into a list of tagnames
        index_list = path.strip().split('/')
        
        # check if the actual object meets the start of the path list
        if self.tag == index_list[0].strip():
            # the start recursive search
            return self.__findtree__(index_list[1:], self)
        raise KeyError

    def __findtree__(self, name_list, tree):
        """
        Recursively searches a tree for an element given by the path list
        This method should be called from __getitem__ to ensure, that name_list
        and tree are consistent
        """
        if name_list == []:
            # if path list is empty, the given element is the searched element
            return tree
        else:
            for element in tree.children:
                if element.tag == name_list[0]:
                    return self.__findtree__(name_list[1:], element)
            raise KeyError

    #=================================================================================================
    # get printable representations of the tree
    #=================================================================================================
    def toTreeString(self, level=0):
        """
        Returns a string, that gives an overview over the included structure elements
        by printing their tags
        """
        result = ' ' * (2 * level)
        result += self.tag + '\n'

        for child in self.children:
            result += child.toTreeString(level + 1)
            
        return result
        
    def toXMLString(self, level=0):
        """
       Return a string, that is the xml representation of the tree
       """
        # prepare resulting string
        result = ''
        # if level = 0 we start with the xml header
        if level == 0:
            result += '<?xml version=\"%s\" encoding=\"%s\"?>\n' % ('1.0', 'UTF-8')

        # start with the tag
        result += ' '*(4 * level)
        result += '<%s' % (self.tag,)

        # if the tag also has attributes, put them into the tag
        if self.attributes != []:
            for attribute in self.attributes:
                result += ' %s=\"%s\"' % attribute

        # if there is neither content nor children, close the tag
        if (self.content == '' and self.children == []):
            result += ' />\n'
            return result
        else:
            result += '>'     # no \n here, because content could follow

        # if there is a content, put it into the result
        if self.content != '':
            result += self.content

        # if there are children, recursively put them to the result
        if self.children != []:
            result += '\n'
            for child in self.children:
                    #result += '\n'
                    result += child.toXMLString(level + 1)
                #result += '\n'
        else:
            result += '</%s>\n' % (self.tag,)
            return result

        result += ' ' * (4 * level)
        result += '</%s>\n' % (self.tag,)

        return result


    #=================================================================================================
    # editing the structure elements
    #=================================================================================================
    def addAttribute(self, attribute, value, pos=None):
        """
        Add a attribute value pair to the element
        """
        if (pos == None or pos > len(self.attributes)):
            self.attributes.append((attribute, value, ))
        else:
            self.attributes.insert(pos, (attribute, value, ))
            
    def delAttribute(self, attrib):
        """
        Delete an attribute from the element.
        If attrib is a string, the list of attributes is searched for an attribute with this name. When the
        attribute with this name is found, it is removed.
        If attrib is an integer the attribute at this position is removed. If the integer is higher
        than len(attributes), a keyError is raised
        """
        if isinstance(attrib, str):
            for attr in self.attributes:
                if attr[0] == attrib:
                    self.attributes.remove(attr)
        elif isinstance(attrib, int):
            if len(self.attributes) > attrib:
                self.attributes.remove(self.attributes[attrib])
            else:
                raise KeyError
        else:
            raise KeyError
                    
        
        
