# coding=UTF-8
"""
 Copyright (C) 2012 Jürgen Baumeister

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
eBookStructure.py
#=====================================================================================================
A module containing the basic structure of an eBook
"""

#=====================================================================================================
# Import section
#=====================================================================================================
from eBookStructElement import eBookStructElement

#=====================================================================================================
# Definition of the basic structure of an eBook
#=====================================================================================================

# Define the basic structure. This has only loose consistency with the physical structure of an eBook
eBook = eBookStructElement('eBook')
eBook.addChild('container')                                                  # will keep the main information of the file containter.xml
eBook.addChild('display_options')                                       # structure of file ....
eBook.addChild('package')                                                      # structure of file content.opf
eBook.addChild('ncx')                                                              # structure of file toc.ncx
eBook.addChild('styles')                                                        # style elements for file styles.css

# Elements kept in file container.xml
eBook['eBook/container'].addChild('rootfiles')
eBook['eBook/container'].addAttribute('version', '1.0')
eBook['eBook/container'].addAttribute('xmlns', 'urn:oasis:names:tc:opendocument:xmlns:container')

eBook['eBook/container/rootfiles'].addChild('rootfile')
eBook['eBook/container/rootfiles/rootfile'].addAttribute('full-path', 'OPS/content.opf')
eBook['eBook/container/rootfiles/rootfile'].addAttribute('media-type', 'application/oebps-package+xml')

# Elements kept in  com.apple.ibooks.display-options.xml
eBook['eBook/display_options'].addChild('platform')
eBook['eBook/display_options/platform'].addAttribute('name', '*')

eBook['eBook/display_options/platform'].addChild('option')
eBook['eBook/display_options/platform/option'].addAttribute('name', 'specified-fonts')
eBook['eBook/display_options/platform/option'].content = 'true'

# Elements kept in content.opf
eBook['eBook/package'].addAttribute('xmlns', 'http://www.idpf.org/2007/opf')
eBook['eBook/package'].addAttribute('unique-identifier', 'BookId')
eBook['eBook/package'].addAttribute('version', '2.0')

eBook['eBook/package'].addChild('metadata')
eBook['eBook/package/metadata'].addAttribute('xmlns:dc', 'http://purl.org/dc/elements/1.1/')
eBook['eBook/package/metadata'].addAttribute('xmlns:dcterms', 'http://purl.org/dc/terms/')
eBook['eBook/package/metadata'].addAttribute('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
eBook['eBook/package/metadata'].addAttribute('xmlns:opf', 'http://www.idpf.org/2007/opf')

eBook['eBook/package/metadata'].addChild('dc:title')
eBook['eBook/package/metadata/dc:title'].content = 'EPUB - Testbuch'

eBook['eBook/package/metadata'].addChild('dc:creator')
eBook['eBook/package/metadata/dc:creator'].content = 'Jürgen Baumeister'

eBook['eBook/package/metadata'].addChild('dc:contributor')
eBook['eBook/package/metadata/dc:contributor'].addAttribute('opf:role', 'bkp')
eBook['eBook/package/metadata/dc:contributor'].content = 'Notepad'

eBook['eBook/package/metadata'].addChild('dc:language')
eBook['eBook/package/metadata/dc:language'].content = 'de'

eBook['eBook/package/metadata'].addChild('dc:identifier')
eBook['eBook/package/metadata/dc:identifier'].addAttribute('id', 'BookId')
eBook['eBook/package/metadata/dc:identifier'].content = 'EPUB - Testbuch'

eBook['eBook/package/metadata'].addChild('dc:subject')
eBook['eBook/package/metadata/dc:subject'].content = 'Test'

eBook['eBook/package/metadata'].addChild('dc:date')
eBook['eBook/package/metadata/dc:date'].content = '2013'

eBook['eBook/package/metadata'].addChild('meta')
eBook['eBook/package/metadata/meta'].addAttribute('name', 'cover')
eBook['eBook/package/metadata/meta'].addAttribute('content', 'cover')


eBook['eBook/package'].addChild('manifest')

eBook['eBook/package/manifest'].addChild('item')
eBook['eBook/package/manifest'].children[0].addAttribute('id', 'toc_ncx')
eBook['eBook/package/manifest'].children[0].addAttribute('href', 'toc.ncx')
eBook['eBook/package/manifest'].children[0].addAttribute('media-type', 'application/x-dtbncx+xml')

eBook['eBook/package/manifest'].addChild('item')
eBook['eBook/package/manifest'].children[1].addAttribute('id', 'cover')
eBook['eBook/package/manifest'].children[1].addAttribute('href', 'Cover.jpg')
eBook['eBook/package/manifest'].children[1].addAttribute('media-type', 'image/jpeg')

eBook['eBook/package/manifest'].addChild('item')
eBook['eBook/package/manifest'].children[2].addAttribute('id', 'CoverPage_html')
eBook['eBook/package/manifest'].children[2].addAttribute('href', 'CoverPage.html')
eBook['eBook/package/manifest'].children[2].addAttribute('media-type', 'application/xhtml+xml')

eBook['eBook/package/manifest'].addChild('item')
eBook['eBook/package/manifest'].children[3].addAttribute('id', 'styles_css')
eBook['eBook/package/manifest'].children[3].addAttribute('href', 'styles.css')
eBook['eBook/package/manifest'].children[3].addAttribute('media-type', 'text/css')

eBook['eBook/package/manifest'].addChild('item')
eBook['eBook/package/manifest'].children[4].addAttribute('id', 'section-0001_html')
eBook['eBook/package/manifest'].children[4].addAttribute('href', 'section-0001.html')
eBook['eBook/package/manifest'].children[4].addAttribute('media-type', 'application/xhtml+xml')
 
eBook['eBook/package'].addChild('spine')

eBook['eBook/package/spine'].addChild('itemref')
eBook['eBook/package/spine'].children[0].addAttribute('idref', 'CoverPage_html')
eBook['eBook/package/spine'].children[0].addAttribute('linear', 'no')

eBook['eBook/package/spine'].addChild('itemref')
eBook['eBook/package/spine'].children[1].addAttribute('idref', 'section-0001_html')

